package mathutils

// Add returns the sum of two numbers
func Add(a, b int) int {
	return a + b
}

// Multiply returns the product of two numbers
func Multiply(a, b int) int {
	return a * b
}

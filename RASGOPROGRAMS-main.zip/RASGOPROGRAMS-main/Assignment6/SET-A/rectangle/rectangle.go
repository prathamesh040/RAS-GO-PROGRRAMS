package rectangle

// CalculateArea returns the area of a rectangle
func CalculateArea(length, width float64) float64 {
	return length * width
}

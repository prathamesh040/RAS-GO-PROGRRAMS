package subtraction

// Subtract returns the difference of two integers
func Subtract(a, b int) int {
	return a - b
}

package square

// Square returns the square of a number
func Square(n int) int {
	return n * n
}

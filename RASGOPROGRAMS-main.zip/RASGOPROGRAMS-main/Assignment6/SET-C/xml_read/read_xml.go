<?xml version="1.0" encoding="UTF-8"?>
<Students>
    <Student>
        <Name>Alice</Name>
        <Age>21</Age>
        <Marks>85</Marks>
    </Student>
    <Student>
        <Name>Bob</Name>
        <Age>22</Age>
        <Marks>90</Marks>
    </Student>
</Students>

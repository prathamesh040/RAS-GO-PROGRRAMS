package operations

// Add returns the sum of two numbers
func Add(a, b int) int {
	return a + b
}

// Subtract returns the difference of two numbers
func Subtract(a, b int) int {
	return a - b
}

// Multiply returns the product of two numbers
func Multiply(a, b int) int {
	return a * b
}

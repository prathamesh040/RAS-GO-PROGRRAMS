package main

import "fmt"

func main() {
    var unusedVar int
    fmt.Println("Hello, Go!")
}

package main

import "fmt"

func main() {
    for i := 2; i <= 20; i += 2 {
        fmt.Println(i)
    }
}

package main

import "fmt"

func main() {
    str := "Hello, Go!"
    fmt.Println(str)
}

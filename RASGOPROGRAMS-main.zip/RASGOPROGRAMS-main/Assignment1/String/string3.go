package main

import "fmt"

func main() {
    str := "Hello, Go!"
    fmt.Println("Length of the string:", len(str))
}

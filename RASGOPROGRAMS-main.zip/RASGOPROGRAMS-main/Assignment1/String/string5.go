package main

import (
    "fmt"
    "strings"
)

func main() {
    str := "HELLO, GO!"
    fmt.Println("Lowercase:", strings.ToLower(str))
}

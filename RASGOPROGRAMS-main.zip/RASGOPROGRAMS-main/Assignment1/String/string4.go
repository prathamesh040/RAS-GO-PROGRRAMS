package main

import (
    "fmt"
    "strings"
)

func main() {
    str := "hello, go!"
    fmt.Println("Uppercase:", strings.ToUpper(str))
}

package main

import "fmt"

func main() {
    str1 := "Hello"
    str2 := "Go!"
    result := str1 + " " + str2
    fmt.Println(result)
}
